// backend/src/config/database.ts
import mysql from 'mysql2/promise';

export const createDatabaseConnection = () => {
  return mysql.createPool({
    host: process.env.HOSTINGER_DB_HOST || 'localhost',
    port: parseInt(process.env.HOSTINGER_DB_PORT || '3306'),
    user: process.env.HOSTINGER_DB_USER || 'u191049593',
    password: process.env.HOSTINGER_DB_PASSWORD || '',
    database: process.env.HOSTINGER_DB_NAME || 'u191049593_CYBER',
    waitForConnections: true,
    connectionLimit: 10, // Hostinger shared hosting limit
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    timezone: '+05:30', // IST timezone
    charset: 'utf8mb4'
  });
};

// Database helper with table prefix
export class CyberDatabase {
  private pool: mysql.Pool;
  private prefix: string;

  constructor() {
    this.pool = createDatabaseConnection();
    this.prefix = process.env.HOSTINGER_DB_PREFIX || 'bms_';
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<T> {
    // Replace table prefixes
    const prefixedSql = sql.replace(/{prefix}/g, this.prefix);
    const [rows] = await this.pool.execute(prefixedSql, params);
    return rows as T;
  }

  getTableName(name: string): string {
    return `${this.prefix}${name}`;
  }

  async beginTransaction(): Promise<mysql.PoolConnection> {
    const connection = await this.pool.getConnection();
    await connection.beginTransaction();
    return connection;
  }

  async commit(connection: mysql.PoolConnection): Promise<void> {
    await connection.commit();
    connection.release();
  }

  async rollback(connection: mysql.PoolConnection): Promise<void> {
    await connection.rollback();
    connection.release();
  }
}

export const db = new CyberDatabase();