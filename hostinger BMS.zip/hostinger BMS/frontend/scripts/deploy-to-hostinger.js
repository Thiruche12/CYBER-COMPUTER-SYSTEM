// frontend/scripts/deploy-to-hostinger.js
const fs = require('fs-extra');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Preparing Hostinger Deployment...');

// Clean previous builds
fs.removeSync('./build');
fs.removeSync('../dist');

// Build React app with Hostinger config
console.log('📦 Building React application...');
execSync('npm run build:hostinger', { stdio: 'inherit' });

// Copy files to dist folder
console.log('📁 Creating deployment package...');
fs.copySync('./build', '../dist');
fs.copySync('../backend/dist', '../dist/api');
fs.copySync('../backend/package.json', '../dist/api/package.json');
fs.copySync('../backend/.env.hostinger', '../dist/api/.env');
fs.copySync('../public_html/.htaccess', '../dist/.htaccess');

// Create README for Hostinger
const readmeContent = `
# Business Management System - Hostinger Installation

## Installation Steps:
1. Upload ALL files to your Hostinger public_html folder
2. Import database/init.sql via phpMyAdmin
3. Update /api/.env with your database credentials
4. Access your site at: https://yourdomain.com

## Default Login:
- Email: admin@bms.com
- Password: admin123

## Support:
For issues, check:
1. Error logs in cPanel
2. Database connection in /api/.env
3. File permissions (folders: 755, files: 644)
`;

fs.writeFileSync('../dist/README_HOSTINGER.md', readmeContent);

console.log('✅ Deployment package created in ../dist/');
console.log('📤 Upload the contents of ../dist/ to Hostinger File Manager');