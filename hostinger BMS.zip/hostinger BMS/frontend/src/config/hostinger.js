// frontend/src/config/hostinger.js
export const hostingerConfig = {
  apiBaseUrl: process.env.NODE_ENV === 'production' 
    ? '/api'  // Relative path for Hostinger
    : 'http://localhost:3000/api',
  
  // Hostinger-specific settings
  uploadPath: '/uploads',
  maxFileSize: 5 * 1024 * 1024, // 5MB
  allowedFileTypes: ['image/jpeg', 'image/png', 'application/pdf'],
  
  // Print settings for Hostinger
  printSettings: {
    a4Paper: {
      width: '210mm',
      height: '297mm',
      margin: '20mm'
    },
    posPaper: {
      width: '80mm',
      height: 'auto',
      margin: '5mm'
    }
  },
  
  // Cache settings for better performance
  cacheConfig: {
    enableCaching: true,
    cacheDuration: 3600000, // 1 hour
    localStoragePrefix: 'bms_'
  }
};