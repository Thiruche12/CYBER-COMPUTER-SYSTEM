// backend/src/app.ts - Updated for Hostinger
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import session from 'express-session';
import path from 'path';
import { Pool } from 'pg';
import dotenv from 'dotenv';

// Load environment variables for Hostinger
dotenv.config({ path: path.join(__dirname, '../.env.hostinger') });

const app = express();

// Hostinger-specific database configuration
export const pool = new Pool({
  user: process.env.HOSTINGER_DB_USER,
  host: process.env.HOSTINGER_DB_HOST,
  database: process.env.HOSTINGER_DB_NAME,
  password: process.env.HOSTINGER_DB_PASSWORD,
  port: parseInt(process.env.HOSTINGER_DB_PORT || '3306'), // Hostinger often uses MySQL
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Middleware optimized for Hostinger shared hosting
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"]
    }
  }
}));

app.use(cors({
  origin: [
    'https://yourdomain.hostingerapp.com',
    'https://www.yourdomain.com',
    'http://localhost:3000'
  ],
  credentials: true
}));

// Rate limiting for Hostinger's shared hosting limits
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// Static files for React build
app.use(express.static(path.join(__dirname, '../../public_html/frontend')));

// API routes
app.use('/api', require('./routes/api'));

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public_html/frontend/index.html'));
});

const PORT = process.env.HOSTINGER_PORT || 3000;
app.listen(PORT, () => {
  console.log(`BMS running on Hostinger port ${PORT}`);
});