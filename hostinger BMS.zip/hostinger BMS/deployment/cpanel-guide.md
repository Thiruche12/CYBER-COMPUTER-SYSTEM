# Hostinger Deployment Guide

## 1. Prerequisites
- Hostinger shared hosting account
- Domain name configured
- MySQL database created via cPanel
- Node.js support enabled (if available)

## 2. Database Setup via cPanel
1. Login to cPanel
2. Go to "MySQL Databases"
3. Create new database: `u123456789_bms`
4. Create user and assign to database
5. Import SQL from `database/init.sql`

## 3. File Upload via File Manager
1. Go to "File Manager" in cPanel
2. Navigate to `public_html`
3. Upload all files from `dist` folder
4. Set permissions:
   - Folders: 755
   - Files: 644
   - `.htaccess`: 644

## 4. Configuration
1. Edit `/api/.env` with your database credentials
2. Update `frontend/.env.production` with your domain

## 5. Cron Jobs Setup (for backups)
In cPanel → Cron Jobs: