#!/bin/bash
# deployment/deploy.sh

echo "🚀 Deploying Business Management System to Hostinger..."

# Configuration
REMOTE_USER="u123456789"
REMOTE_HOST="ftp.yourdomain.com"
REMOTE_PATH="/domains/yourdomain.com/public_html"
LOCAL_PATH="./dist"
BACKUP_PATH="./backups/$(date +%Y%m%d_%H%M%S)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print status
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Step 1: Build frontend
print_status "Building React application..."
cd frontend
npm run build
if [ $? -ne 0 ]; then
    print_error "Frontend build failed!"
    exit 1
fi

# Step 2: Prepare backend
print_status "Preparing backend..."
cd ../backend
npm run build
if [ $? -ne 0 ]; then
    print_error "Backend build failed!"
    exit 1
fi

# Step 3: Create deployment package
print_status "Creating deployment package..."
cd ..
mkdir -p dist
mkdir -p $BACKUP_PATH

# Copy frontend build
cp -r frontend/build/* dist/

# Copy backend
mkdir -p dist/api
cp -r backend/dist/* dist/api/
cp backend/package.json dist/api/
cp backend/.env.hostinger dist/api/.env

# Copy configuration files
cp -r public_html/.htaccess dist/
cp -r deployment/hostinger-config.json dist/

# Create database backup script
cat > dist/database-backup.sh << 'EOF'
#!/bin/bash
# Database backup script for Hostinger
BACKUP_DIR="/home/u123456789/backups"
DB_NAME="u123456789_bms"
DATE=$(date +%Y%m%d_%H%M%S)

mysqldump -u u123456789_bms_user -p'YourPassword' $DB_NAME > $BACKUP_DIR/bms_backup_$DATE.sql
gzip $BACKUP_DIR/bms_backup_$DATE.sql

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.gz" -mtime +7 -delete

echo "Backup completed: bms_backup_$DATE.sql.gz"
EOF

chmod +x dist/database-backup.sh

# Step 4: Deploy to Hostinger using FTP/SSH
print_status "Deploying to Hostinger..."

# Method 1: Using lftp (recommended for Hostinger)
if command -v lftp &> /dev/null; then
    lftp -e "
        set ftp:ssl-allow no;
        open ftp://$REMOTE_USER@$REMOTE_HOST;
        mkdir -p $REMOTE_PATH/backup;
        mirror -R --verbose=3 --delete $LOCAL_PATH $REMOTE_PATH;
        bye
    "
elif command -v scp &> /dev/null && [ -f ~/.ssh/id_rsa ]; then
    # Method 2: Using SCP/SSH
    scp -r $LOCAL_PATH/* $REMOTE_USER@$REMOTE_HOST:$REMOTE_PATH/
else
    # Method 3: Using cPanel API
    print_warning "Direct deployment methods not available. Please upload via File Manager."
    print_status "Package created at: $LOCAL_PATH"
    print_status "Upload these files to Hostinger File Manager"
fi

# Step 5: Set permissions
print_status "Setting file permissions..."
ssh $REMOTE_USER@$REMOTE_HOST << 'EOF'
    chmod 755 /domains/yourdomain.com/public_html
    chmod 644 /domains/yourdomain.com/public_html/.htaccess
    chmod 755 /domains/yourdomain.com/public_html/api
    chmod 644 /domains/yourdomain.com/public_html/api/.env
    chmod -R 755 /domains/yourdomain.com/public_html/uploads
EOF

print_status "Deployment completed successfully!"
print_status "Access your BMS at: https://yourdomain.com"