#!/bin/bash
# deployment/deploy-cyber.sh

echo "🚀 Deploying Cyber Business Management System to Hostinger..."

# Configuration for u191049593_CYBER
REMOTE_USER="u191049593"
REMOTE_HOST="ftp.yourdomain.com"  # Your Hostinger FTP host
REMOTE_PATH="/domains/yourdomain.com/public_html"
LOCAL_PATH="./cyber-dist"
DB_NAME="u191049593_CYBER"
DB_USER="u191049593"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}=== $1 ===${NC}"
}

print_success() {
    echo -e "${GREEN}[✓] $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

print_error() {
    echo -e "${RED}[✗] $1${NC}"
}

# Step 1: Clean previous build
print_header "Cleaning previous build"
rm -rf $LOCAL_PATH
mkdir -p $LOCAL_PATH

# Step 2: Build frontend
print_header "Building React Frontend"
cd frontend
npm install
npm run build:hostinger

if [ $? -ne 0 ]; then
    print_error "Frontend build failed!"
    exit 1
fi
print_success "Frontend built successfully"

# Step 3: Build backend
print_header "Building Backend API"
cd ../backend
npm install
npm run build

if [ $? -ne 0 ]; then
    print_error "Backend build failed!"
    exit 1
fi
print_success "Backend built successfully"

# Step 4: Create deployment package
print_header "Creating deployment package"
cd ..

# Copy frontend build
cp -r frontend/build/* $LOCAL_PATH/

# Create API directory
mkdir -p $LOCAL_PATH/api

# Copy backend files
cp -r backend/dist/* $LOCAL_PATH/api/
cp backend/package.json $LOCAL_PATH/api/
cp backend/.env.hostinger $LOCAL_PATH/api/.env
cp backend/ecosystem.config.js $LOCAL_PATH/api/  # For PM2

# Create .htaccess for Hostinger
cat > $LOCAL_PATH/.htaccess << 'EOF'
RewriteEngine On
RewriteBase /

# Security headers
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"
Header set Referrer-Policy "strict-origin-when-cross-origin"

# Compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
</IfModule>

# Cache control
<FilesMatch "\.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$">
    Header set Cache-Control "max-age=31536000, public"
</FilesMatch>

# API routing
RewriteRule ^api/(.*)$ /api/index.php?path=$1 [QSA,L]

# React routing
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [L]

# Prevent directory listing
Options -Indexes

# Protect sensitive files
<FilesMatch "\.(env|log|sql|config)$">
    Order allow,deny
    Deny from all
</FilesMatch>
EOF

# Create index.php for API routing
cat > $LOCAL_PATH/api/index.php << 'EOF'
<?php
// Hostinger PHP proxy for Node.js API
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$path = $_GET['path'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$input = file_get_contents('php://input');
$headers = getallheaders();

// Forward to Node.js server (if running)
$url = 'http://localhost:3000/api/' . $path;
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
curl_setopt($ch, CURLOPT_POSTFIELDS, $input);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: ' . ($headers['Authorization'] ?? '')
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

http_response_code($httpCode);
echo $response;

curl_close($ch);
EOF

# Create installation guide
cat > $LOCAL_PATH/INSTALL_HOSTINGER.md << 'EOF'
# Cyber Business Management System - Hostinger Installation

## Database Setup
1. Login to Hostinger cPanel
2. Go to MySQL Databases
3. Create database: `u191049593_CYBER`
4. Create user: `u191049593`
5. Assign user to database with ALL privileges
6. Import SQL from: `database/u191049593_CYBER.sql`

## File Upload
1. Upload ALL files from this folder to `public_html`
2. Set permissions:
   - Folders: 755
   - Files: 644
   - api/.env: 600 (for security)

## Configuration
Edit `/api/.env`: